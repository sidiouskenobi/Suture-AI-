import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import '../models/contentrow_item_model.dart';
import '../models/time_capsule_model.dart';
part 'time_capsule_event.dart';
part 'time_capsule_state.dart';

/// A bloc that manages the state of a TimeCapsule according to the event that is dispatched to it.
class TimeCapsuleBloc extends Bloc<TimeCapsuleEvent, TimeCapsuleState> {
  TimeCapsuleBloc(TimeCapsuleState initialState) : super(initialState) {
    on<TimeCapsuleInitialEvent>(_onInitialize);
  }

  _onInitialize(
    TimeCapsuleInitialEvent event,
    Emitter<TimeCapsuleState> emit,
  ) async {
    emit(state.copyWith(
        timeCapsuleModelObj: state.timeCapsuleModelObj?.copyWith(
      contentrowItemList: fillContentrowItemList(),
    )));
  }

  List<ContentrowItemModel> fillContentrowItemList() {
    return [
      ContentrowItemModel(
          image: ImageConstant.imgImage,
          headline: "FIGO Classification",
          description: "Staging of Endometrial Cancer",
          heartIcon: ImageConstant.imgHeartOutline),
      ContentrowItemModel(
          image: ImageConstant.imgImage72x72,
          headline: "WSES guidelines",
          description: "Complicated abdominal wall hernias",
          heartIcon: ImageConstant.imgHeartOutline),
      ContentrowItemModel(
          image: ImageConstant.imgImage3,
          headline: "WSES spleen trauma",
          description: "Spleen Trauma Classification",
          heartIcon: ImageConstant.imgHeartOutline),
      ContentrowItemModel(
          image: ImageConstant.imgImage4,
          headline: "Row Header",
          description: "Body copy description",
          heartIcon: ImageConstant.imgHeartOutlineGray900),
      ContentrowItemModel(
          image: ImageConstant.imgImage4,
          headline: "Row Header",
          description: "Body copy description",
          heartIcon: ImageConstant.imgHeartOutlineGray900)
    ];
  }
}
