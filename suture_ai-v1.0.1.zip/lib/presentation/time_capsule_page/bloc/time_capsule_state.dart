part of 'time_capsule_bloc.dart';

/// Represents the state of TimeCapsule in the application.

// ignore_for_file: must_be_immutable
class TimeCapsuleState extends Equatable {
  TimeCapsuleState({this.timeCapsuleModelObj});

  TimeCapsuleModel? timeCapsuleModelObj;

  @override
  List<Object?> get props => [timeCapsuleModelObj];
  TimeCapsuleState copyWith({TimeCapsuleModel? timeCapsuleModelObj}) {
    return TimeCapsuleState(
      timeCapsuleModelObj: timeCapsuleModelObj ?? this.timeCapsuleModelObj,
    );
  }
}
