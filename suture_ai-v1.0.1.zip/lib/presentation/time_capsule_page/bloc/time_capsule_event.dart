part of 'time_capsule_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///TimeCapsule widget.
///
/// Events must be immutable and implement the [Equatable] interface.
class TimeCapsuleEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the TimeCapsule widget is first created.
class TimeCapsuleInitialEvent extends TimeCapsuleEvent {
  @override
  List<Object?> get props => [];
}
