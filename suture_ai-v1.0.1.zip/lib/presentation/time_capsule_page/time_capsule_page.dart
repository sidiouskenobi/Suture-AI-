import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_subtitle.dart';
import '../../widgets/app_bar/appbar_subtitle_four.dart';
import '../../widgets/app_bar/appbar_trailing_iconbutton.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import 'bloc/time_capsule_bloc.dart';
import 'models/contentrow_item_model.dart';
import 'models/time_capsule_model.dart';
import 'widgets/contentrow_item_widget.dart'; // ignore_for_file: must_be_immutable

class TimeCapsulePage extends StatelessWidget {
  const TimeCapsulePage({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<TimeCapsuleBloc>(
      create: (context) => TimeCapsuleBloc(TimeCapsuleState(
        timeCapsuleModelObj: TimeCapsuleModel(),
      ))
        ..add(TimeCapsuleInitialEvent()),
      child: TimeCapsulePage(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.gray100,
        appBar: _buildAppbar(context),
        body: Padding(
          padding: EdgeInsets.only(
            left: 16.h,
            top: 16.v,
            right: 16.h,
          ),
          child: BlocSelector<TimeCapsuleBloc, TimeCapsuleState,
              TimeCapsuleModel?>(
            selector: (state) => state.timeCapsuleModelObj,
            builder: (context, timeCapsuleModelObj) {
              return ListView.separated(
                physics: BouncingScrollPhysics(),
                shrinkWrap: true,
                separatorBuilder: (context, index) {
                  return SizedBox(
                    height: 16.v,
                  );
                },
                itemCount: timeCapsuleModelObj?.contentrowItemList.length ?? 0,
                itemBuilder: (context, index) {
                  ContentrowItemModel model =
                      timeCapsuleModelObj?.contentrowItemList[index] ??
                          ContentrowItemModel();
                  return ContentrowItemWidget(
                    model,
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppbar(BuildContext context) {
    return CustomAppBar(
      title: Padding(
        padding: EdgeInsets.only(left: 16.h),
        child: Column(
          children: [
            AppbarSubtitle(
              text: "lbl_time_pulse".tr,
              margin: EdgeInsets.only(right: 125.h),
            ),
            SizedBox(height: 2.v),
            AppbarSubtitleFour(
              text: "msg_guidelines_that".tr,
            )
          ],
        ),
      ),
      actions: [
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgSearch,
          margin: EdgeInsets.only(
            left: 8.h,
            top: 14.v,
            right: 22.h,
          ),
        ),
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgIconBgLight,
          margin: EdgeInsets.only(
            left: 4.h,
            top: 14.v,
            right: 30.h,
          ),
        )
      ],
      styleType: Style.bgFill,
    );
  }
}
