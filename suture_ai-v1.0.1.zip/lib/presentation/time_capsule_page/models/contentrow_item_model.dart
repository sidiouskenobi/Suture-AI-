import '../../../core/app_export.dart';

/// This class is used in the [contentrow_item_widget] screen.
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class ContentrowItemModel {
  ContentrowItemModel(
      {this.image, this.headline, this.description, this.heartIcon, this.id}) {
    image = image ?? ImageConstant.imgImage;
    headline = headline ?? "FIGO Classification";
    description = description ?? "Staging of Endometrial Cancer";
    heartIcon = heartIcon ?? ImageConstant.imgHeartOutline;
    id = id ?? "";
  }

  String? image;

  String? headline;

  String? description;

  String? heartIcon;

  String? id;
}
