import 'package:flutter/material.dart';
import '../../../core/app_export.dart';
import '../../../widgets/custom_elevated_button.dart';
import '../../../widgets/custom_icon_button.dart';
import '../models/contentrow_item_model.dart'; // ignore: must_be_immutable
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class ContentrowItemWidget extends StatelessWidget {
  ContentrowItemWidget(this.contentrowItemModelObj, {Key? key})
      : super(
          key: key,
        );

  ContentrowItemModel contentrowItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 12.v),
      decoration: AppDecoration.fillWhiteA.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          CustomImageView(
            imagePath: contentrowItemModelObj?.image,
            height: 72.adaptSize,
            width: 72.adaptSize,
            radius: BorderRadius.circular(
              8.h,
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 14.v),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  contentrowItemModelObj.headline!,
                  style: theme.textTheme.titleMedium,
                ),
                SizedBox(height: 4.v),
                Text(
                  contentrowItemModelObj.description!,
                  style: CustomTextStyles.bodyMediumWhiteA700,
                )
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTimeStamp(context),
              SizedBox(height: 4.v),
              CustomIconButton(
                height: 40.adaptSize,
                width: 40.adaptSize,
                padding: EdgeInsets.all(8.h),
                alignment: Alignment.centerRight,
                child: CustomImageView(
                  imagePath: contentrowItemModelObj?.heartIcon,
                ),
              )
            ],
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildTimeStamp(BuildContext context) {
    return CustomElevatedButton(
      width: 45.h,
      text: "lbl_9_30".tr,
      buttonTextStyle: theme.textTheme.bodyMedium!,
      alignment: Alignment.center,
    );
  }
}
