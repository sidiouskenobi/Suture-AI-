import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_subtitle_two.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/appbar_trailing_iconbutton.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_rating_bar.dart';
import '../time_capsule_page/time_capsule_page.dart';
import '../wses_guidelines_hernias_page/wses_guidelines_hernias_page.dart';
import 'bloc/profile_bloc.dart';
import 'models/profile_model.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class ProfileScreen extends StatelessWidget {
  ProfileScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<ProfileBloc>(
      create: (context) => ProfileBloc(ProfileState(
        profileModelObj: ProfileModel(),
      ))
        ..add(ProfileInitialEvent()),
      child: ProfileScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ProfileBloc, ProfileState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            appBar: _buildAppbar(context),
            body: Container(
              width: double.maxFinite,
              padding: EdgeInsets.symmetric(
                horizontal: 16.h,
                vertical: 39.v,
              ),
              child: Column(
                children: [
                  SizedBox(height: 3.v),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 29.h),
                    child: Column(
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgImage120x120,
                          height: 120.adaptSize,
                          width: 120.adaptSize,
                          radius: BorderRadius.circular(
                            60.h,
                          ),
                        ),
                        SizedBox(height: 13.v),
                        Text(
                          "msg_dr_muhammad_khan".tr,
                          style: CustomTextStyles.headlineMediumBlack900,
                        ),
                        SizedBox(height: 8.v),
                        Text(
                          "msg_assistant_professor".tr,
                          style: theme.textTheme.bodyLarge,
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 37.v),
                  Padding(
                    padding: EdgeInsets.only(
                      left: 34.h,
                      right: 22.h,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          children: [
                            Text(
                              "lbl_joined".tr,
                              style: theme.textTheme.titleSmall,
                            ),
                            SizedBox(height: 5.v),
                            Text(
                              "lbl_2022".tr,
                              style: CustomTextStyles.titleMedium19,
                            )
                          ],
                        ),
                        Spacer(
                          flex: 54,
                        ),
                        Column(
                          children: [
                            Text(
                              "lbl_cme_hours".tr,
                              style: theme.textTheme.titleSmall,
                            ),
                            SizedBox(height: 5.v),
                            Text(
                              "lbl_48_5".tr,
                              style: CustomTextStyles.titleMedium19,
                            )
                          ],
                        ),
                        Spacer(
                          flex: 45,
                        ),
                        Column(
                          children: [
                            Text(
                              "lbl_pmdc_no".tr,
                              style: theme.textTheme.titleSmall,
                            ),
                            SizedBox(height: 5.v),
                            Text(
                              "lbl_189282".tr,
                              style: CustomTextStyles.titleMedium19,
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 21.v),
                  _buildCopy(context),
                  SizedBox(height: 42.v),
                  _buildContent(context)
                ],
              ),
            ),
            bottomNavigationBar: _buildBottombar(context),
          ),
        );
      },
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppbar(BuildContext context) {
    return CustomAppBar(
      title: Padding(
        padding: EdgeInsets.only(left: 16.h),
        child: Column(
          children: [
            AppbarTitle(
              text: "lbl_my_profile".tr,
              margin: EdgeInsets.only(right: 35.h),
            ),
            AppbarSubtitleTwo(
              text: "msg_welcome_muhammad".tr,
            )
          ],
        ),
      ),
      actions: [
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgSearchBlack900,
          margin: EdgeInsets.only(
            left: 8.h,
            top: 14.v,
            right: 22.h,
          ),
        ),
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgIconBgLightBlack900,
          margin: EdgeInsets.only(
            left: 4.h,
            top: 14.v,
            right: 30.h,
          ),
        )
      ],
      styleType: Style.bgFill_1,
    );
  }

  /// Section Widget
  Widget _buildCopy(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 3.h,
        right: 1.h,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "lbl_notifications".tr,
            style: CustomTextStyles.titleMediumLightblue700,
          ),
          SizedBox(height: 1.v),
          SizedBox(
            width: 352.h,
            child: Text(
              "msg_dr_a_dhesiv_replied".tr,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: CustomTextStyles.bodyMediumBlack900.copyWith(
                height: 1.43,
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildContent(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 1.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "msg_recently_accessed".tr,
            style: CustomTextStyles.titleMediumLightblue700,
          ),
          SizedBox(
            width: 355.h,
            child: Text(
              "msg_what_can_the_new".tr,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: CustomTextStyles.bodyMediumBlack900.copyWith(
                height: 1.43,
              ),
            ),
          ),
          SizedBox(height: 7.v),
          CustomRatingBar(
            initialRating: 0,
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottombar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Activity:
        return AppRoutes.timeCapsulePage;
      case BottomBarEnum.Messagecircle:
        return AppRoutes.wsesGuidelinesHerniasPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.timeCapsulePage:
        return TimeCapsulePage.builder(context);
      case AppRoutes.wsesGuidelinesHerniasPage:
        return WsesGuidelinesHerniasPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
