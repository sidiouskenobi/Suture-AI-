import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_subtitle_one.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../time_capsule_page/time_capsule_page.dart';
import '../wses_guidelines_hernias_page/wses_guidelines_hernias_page.dart';
import 'bloc/podcast_bloc.dart';
import 'models/podcast_model.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class PodcastScreen extends StatelessWidget {
  PodcastScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<PodcastBloc>(
      create: (context) => PodcastBloc(PodcastState(
        podcastModelObj: PodcastModel(),
      ))
        ..add(PodcastInitialEvent()),
      child: PodcastScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PodcastBloc, PodcastState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            appBar: _buildAppbar(context),
            body: Container(
              width: double.maxFinite,
              padding: EdgeInsets.symmetric(
                horizontal: 16.h,
                vertical: 10.v,
              ),
              child: Column(
                children: [
                  Text(
                    "msg_wses_guidelines".tr,
                    style: CustomTextStyles.bodyLargeRobotoGray800,
                  ),
                  SizedBox(height: 13.v),
                  CustomImageView(
                    imagePath: ImageConstant.imgImage1358x358,
                    height: 358.adaptSize,
                    width: 358.adaptSize,
                    radius: BorderRadius.circular(
                      15.h,
                    ),
                  ),
                  SizedBox(height: 31.v),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      "lbl_general_surgery".tr,
                      style: CustomTextStyles.bodyLargeRobotoGray800,
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      "lbl_wses_guidelines2".tr,
                      style: theme.textTheme.headlineSmall,
                    ),
                  ),
                  SizedBox(height: 30.v),
                  CustomImageView(
                    imagePath: ImageConstant.imgGroup226,
                    height: 19.v,
                    width: 358.h,
                  ),
                  SizedBox(height: 1.v),
                  _buildRowtime(context),
                  SizedBox(height: 19.v),
                  CustomImageView(
                    imagePath: ImageConstant.imgFrame300,
                    height: 46.v,
                    width: 342.h,
                  )
                ],
              ),
            ),
            bottomNavigationBar: _buildBottombar(context),
          ),
        );
      },
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppbar(BuildContext context) {
    return CustomAppBar(
      height: 70.v,
      leadingWidth: 40.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(
          left: 16.h,
          top: 16.v,
          bottom: 16.v,
        ),
        onTap: () {
          onTapArrowleftone(context);
        },
      ),
      centerTitle: true,
      title: AppbarSubtitleOne(
        text: "lbl_suture_ai".tr,
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgMoreHorizontal,
          margin: EdgeInsets.all(16.h),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildRowtime(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          "lbl_02_34".tr,
          style: CustomTextStyles.bodyMediumRobotoLightblue700,
        ),
        Text(
          "lbl_05_30".tr,
          style: CustomTextStyles.bodyMediumRobotoLightblue700,
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildBottombar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Activity:
        return AppRoutes.timeCapsulePage;
      case BottomBarEnum.Messagecircle:
        return AppRoutes.wsesGuidelinesHerniasPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.timeCapsulePage:
        return TimeCapsulePage.builder(context);
      case AppRoutes.wsesGuidelinesHerniasPage:
        return WsesGuidelinesHerniasPage.builder(context);
      default:
        return DefaultWidget();
    }
  }

  /// Navigates to the previous screen.
  onTapArrowleftone(BuildContext context) {
    NavigatorService.goBack();
  }
}
