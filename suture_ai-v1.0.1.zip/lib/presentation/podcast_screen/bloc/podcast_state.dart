part of 'podcast_bloc.dart';

/// Represents the state of Podcast in the application.

// ignore_for_file: must_be_immutable
class PodcastState extends Equatable {
  PodcastState({this.podcastModelObj});

  PodcastModel? podcastModelObj;

  @override
  List<Object?> get props => [podcastModelObj];
  PodcastState copyWith({PodcastModel? podcastModelObj}) {
    return PodcastState(
      podcastModelObj: podcastModelObj ?? this.podcastModelObj,
    );
  }
}
