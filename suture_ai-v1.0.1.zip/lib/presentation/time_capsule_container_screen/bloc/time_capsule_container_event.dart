part of 'time_capsule_container_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///TimeCapsuleContainer widget.
///
/// Events must be immutable and implement the [Equatable] interface.
class TimeCapsuleContainerEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the TimeCapsuleContainer widget is first created.
class TimeCapsuleContainerInitialEvent extends TimeCapsuleContainerEvent {
  @override
  List<Object?> get props => [];
}
