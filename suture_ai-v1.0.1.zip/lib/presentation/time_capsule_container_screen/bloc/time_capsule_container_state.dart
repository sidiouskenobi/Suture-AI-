part of 'time_capsule_container_bloc.dart';

/// Represents the state of TimeCapsuleContainer in the application.

// ignore_for_file: must_be_immutable
class TimeCapsuleContainerState extends Equatable {
  TimeCapsuleContainerState({this.timeCapsuleContainerModelObj});

  TimeCapsuleContainerModel? timeCapsuleContainerModelObj;

  @override
  List<Object?> get props => [timeCapsuleContainerModelObj];
  TimeCapsuleContainerState copyWith(
      {TimeCapsuleContainerModel? timeCapsuleContainerModelObj}) {
    return TimeCapsuleContainerState(
      timeCapsuleContainerModelObj:
          timeCapsuleContainerModelObj ?? this.timeCapsuleContainerModelObj,
    );
  }
}
