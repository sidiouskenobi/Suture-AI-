import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import '../models/time_capsule_container_model.dart';
part 'time_capsule_container_event.dart';
part 'time_capsule_container_state.dart';

/// A bloc that manages the state of a TimeCapsuleContainer according to the event that is dispatched to it.
class TimeCapsuleContainerBloc
    extends Bloc<TimeCapsuleContainerEvent, TimeCapsuleContainerState> {
  TimeCapsuleContainerBloc(TimeCapsuleContainerState initialState)
      : super(initialState) {
    on<TimeCapsuleContainerInitialEvent>(_onInitialize);
  }

  _onInitialize(
    TimeCapsuleContainerInitialEvent event,
    Emitter<TimeCapsuleContainerState> emit,
  ) async {}
}
