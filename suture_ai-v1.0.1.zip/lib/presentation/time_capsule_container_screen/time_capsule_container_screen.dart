import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../time_capsule_page/time_capsule_page.dart';
import '../wses_guidelines_hernias_page/wses_guidelines_hernias_page.dart';
import 'bloc/time_capsule_container_bloc.dart';
import 'models/time_capsule_container_model.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class TimeCapsuleContainerScreen extends StatelessWidget {
  TimeCapsuleContainerScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<TimeCapsuleContainerBloc>(
      create: (context) => TimeCapsuleContainerBloc(TimeCapsuleContainerState(
        timeCapsuleContainerModelObj: TimeCapsuleContainerModel(),
      ))
        ..add(TimeCapsuleContainerInitialEvent()),
      child: TimeCapsuleContainerScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TimeCapsuleContainerBloc, TimeCapsuleContainerState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: appTheme.gray100,
            body: Navigator(
              key: navigatorKey,
              initialRoute: AppRoutes.timeCapsulePage,
              onGenerateRoute: (routeSetting) => PageRouteBuilder(
                pageBuilder: (ctx, ani, ani1) =>
                    getCurrentPage(context, routeSetting.name!),
                transitionDuration: Duration(seconds: 0),
              ),
            ),
            bottomNavigationBar: _buildBottombar(context),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildBottombar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Activity:
        return AppRoutes.timeCapsulePage;
      case BottomBarEnum.Messagecircle:
        return AppRoutes.wsesGuidelinesHerniasPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.timeCapsulePage:
        return TimeCapsulePage.builder(context);
      case AppRoutes.wsesGuidelinesHerniasPage:
        return WsesGuidelinesHerniasPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
