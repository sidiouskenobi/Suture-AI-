import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import '../models/surgeon_s_lounge_model.dart';
part 'surgeon_s_lounge_event.dart';
part 'surgeon_s_lounge_state.dart';

/// A bloc that manages the state of a SurgeonSLounge according to the event that is dispatched to it.
class SurgeonSLoungeBloc
    extends Bloc<SurgeonSLoungeEvent, SurgeonSLoungeState> {
  SurgeonSLoungeBloc(SurgeonSLoungeState initialState) : super(initialState) {
    on<SurgeonSLoungeInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SurgeonSLoungeInitialEvent event,
    Emitter<SurgeonSLoungeState> emit,
  ) async {
    emit(state.copyWith(
      messageController: TextEditingController(),
    ));
  }
}
