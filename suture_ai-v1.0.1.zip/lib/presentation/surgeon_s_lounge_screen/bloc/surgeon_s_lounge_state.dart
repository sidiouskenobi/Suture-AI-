part of 'surgeon_s_lounge_bloc.dart';

/// Represents the state of SurgeonSLounge in the application.

// ignore_for_file: must_be_immutable
class SurgeonSLoungeState extends Equatable {
  SurgeonSLoungeState({this.messageController, this.surgeonSLoungeModelObj});

  TextEditingController? messageController;

  SurgeonSLoungeModel? surgeonSLoungeModelObj;

  @override
  List<Object?> get props => [messageController, surgeonSLoungeModelObj];
  SurgeonSLoungeState copyWith({
    TextEditingController? messageController,
    SurgeonSLoungeModel? surgeonSLoungeModelObj,
  }) {
    return SurgeonSLoungeState(
      messageController: messageController ?? this.messageController,
      surgeonSLoungeModelObj:
          surgeonSLoungeModelObj ?? this.surgeonSLoungeModelObj,
    );
  }
}
