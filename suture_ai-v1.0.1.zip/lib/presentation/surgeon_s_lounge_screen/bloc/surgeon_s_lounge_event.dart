part of 'surgeon_s_lounge_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///SurgeonSLounge widget.
///
/// Events must be immutable and implement the [Equatable] interface.
class SurgeonSLoungeEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the SurgeonSLounge widget is first created.
class SurgeonSLoungeInitialEvent extends SurgeonSLoungeEvent {
  @override
  List<Object?> get props => [];
}
