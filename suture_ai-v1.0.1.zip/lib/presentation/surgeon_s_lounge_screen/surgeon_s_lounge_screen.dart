import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_image.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_text_form_field.dart';
import '../time_capsule_page/time_capsule_page.dart';
import '../wses_guidelines_hernias_page/wses_guidelines_hernias_page.dart';
import 'bloc/surgeon_s_lounge_bloc.dart';
import 'models/surgeon_s_lounge_model.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class SurgeonSLoungeScreen extends StatelessWidget {
  SurgeonSLoungeScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<SurgeonSLoungeBloc>(
      create: (context) => SurgeonSLoungeBloc(SurgeonSLoungeState(
        surgeonSLoungeModelObj: SurgeonSLoungeModel(),
      ))
        ..add(SurgeonSLoungeInitialEvent()),
      child: SurgeonSLoungeScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.gray100,
        resizeToAvoidBottomInset: false,
        appBar: _buildAppbar(context),
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 529.v,
                width: 336.h,
                margin: EdgeInsets.only(left: 16.h),
                child: Stack(
                  alignment: Alignment.topRight,
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Container(
                        height: 30.v,
                        width: 28.h,
                        margin: EdgeInsets.only(top: 64.v),
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            CustomImageView(
                              imagePath: ImageConstant.imgUser,
                              height: 24.adaptSize,
                              width: 24.adaptSize,
                              alignment: Alignment.topCenter,
                              margin: EdgeInsets.only(top: 2.v),
                            ),
                            CustomImageView(
                              imagePath: ImageConstant.imgCircle,
                              height: 30.v,
                              width: 28.h,
                              alignment: Alignment.center,
                            )
                          ],
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.topRight,
                      child: Container(
                        margin: EdgeInsets.only(
                          left: 204.h,
                          right: 86.h,
                        ),
                        padding: EdgeInsets.symmetric(
                          horizontal: 8.h,
                          vertical: 3.v,
                        ),
                        decoration: AppDecoration.fillBlueGrayCc.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder4,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(height: 2.v),
                            Text(
                              "lbl_9_30".tr,
                              style: theme.textTheme.bodyMedium,
                            )
                          ],
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Padding(
                        padding: EdgeInsets.only(left: 48.h),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              padding: EdgeInsets.all(12.h),
                              decoration: AppDecoration.fillWhiteA700.copyWith(
                                borderRadius: BorderRadiusStyle.roundedBorder12,
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomImageView(
                                    imagePath: ImageConstant.imgImage197x264,
                                    height: 197.v,
                                    width: 264.h,
                                    radius: BorderRadius.circular(
                                      12.h,
                                    ),
                                  ),
                                  SizedBox(height: 8.v),
                                  Container(
                                    width: 217.h,
                                    margin: EdgeInsets.only(right: 46.h),
                                    child: Text(
                                      "msg_what_a_great_review".tr,
                                      maxLines: 3,
                                      overflow: TextOverflow.ellipsis,
                                      style: CustomTextStyles.bodyLargeBlack900
                                          .copyWith(
                                        height: 1.50,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 7.v),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: Container(
                                      margin: EdgeInsets.only(left: 219.h),
                                      padding: EdgeInsets.symmetric(
                                        horizontal: 8.h,
                                        vertical: 3.v,
                                      ),
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadiusStyle.roundedBorder4,
                                      ),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          SizedBox(height: 2.v),
                                          Text(
                                            "lbl_9_30".tr,
                                            style: CustomTextStyles
                                                .bodyMediumWhiteA700_1,
                                          )
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(height: 8.v),
                            Container(
                              padding: EdgeInsets.all(12.h),
                              decoration: AppDecoration.fillWhiteA700.copyWith(
                                borderRadius: BorderRadiusStyle.roundedBorder12,
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Container(
                                    width: 257.h,
                                    margin: EdgeInsets.only(right: 6.h),
                                    child: Text(
                                      "msg_i_regret_going_through".tr,
                                      maxLines: 3,
                                      overflow: TextOverflow.ellipsis,
                                      style: CustomTextStyles.bodyLargeBlack900
                                          .copyWith(
                                        height: 1.50,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 7.v),
                                  Container(
                                    margin: EdgeInsets.only(left: 219.h),
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 8.h,
                                      vertical: 3.v,
                                    ),
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder4,
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(height: 2.v),
                                        Text(
                                          "lbl_9_30".tr,
                                          style: CustomTextStyles
                                              .bodyMediumWhiteA700_1,
                                        )
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(height: 13.v),
              _buildStackloremipsum(context)
            ],
          ),
        ),
        bottomNavigationBar: _buildBottombar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppbar(BuildContext context) {
    return CustomAppBar(
      height: 74.v,
      title: AppbarTitle(
        text: "msg_surgeon_s_lounge".tr,
        margin: EdgeInsets.only(
          left: 16.h,
          top: 3.v,
          bottom: 37.v,
        ),
      ),
      actions: [
        Container(
          margin: EdgeInsets.only(
            left: 8.h,
            top: 12.v,
            right: 22.h,
          ),
          padding: EdgeInsets.all(8.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadiusStyle.circleBorder20,
          ),
          child: AppbarImage(
            imagePath: ImageConstant.imgSearchWhiteA700,
          ),
        ),
        Container(
          margin: EdgeInsets.only(
            left: 4.h,
            top: 12.v,
            right: 30.h,
          ),
          padding: EdgeInsets.all(8.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadiusStyle.circleBorder20,
          ),
          child: AppbarImage(
            imagePath: ImageConstant.imgIconBgLightWhiteA700,
          ),
        )
      ],
      styleType: Style.bgFill_1,
    );
  }

  /// Section Widget
  Widget _buildStackloremipsum(BuildContext context) {
    return SizedBox(
      height: 132.v,
      width: double.maxFinite,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Align(
            alignment: Alignment.topRight,
            child: Container(
              margin: EdgeInsets.only(
                left: 64.h,
                right: 34.h,
              ),
              padding: EdgeInsets.symmetric(horizontal: 12.h),
              decoration: AppDecoration.fillBlueGray.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder12,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  SizedBox(height: 12.v),
                  SizedBox(
                    width: 268.h,
                    child: Text(
                      "msg_thanks_for_letting".tr,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: CustomTextStyles.bodyLargeBlack900.copyWith(
                        height: 1.50,
                      ),
                    ),
                  ),
                  SizedBox(height: 7.v),
                  Container(
                    margin: EdgeInsets.only(left: 223.h),
                    padding: EdgeInsets.symmetric(horizontal: 8.h),
                    decoration: AppDecoration.fillBlueGray.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder4,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(height: 4.v),
                        Text(
                          "lbl_9_30".tr,
                          style: CustomTextStyles.bodyMediumWhiteA700_1,
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: double.maxFinite,
              margin: EdgeInsets.only(top: 66.v),
              padding: EdgeInsets.symmetric(
                horizontal: 16.h,
                vertical: 8.v,
              ),
              decoration: AppDecoration.fillWhiteA700,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.only(bottom: 10.v),
                    child: CustomIconButton(
                      height: 40.adaptSize,
                      width: 40.adaptSize,
                      padding: EdgeInsets.all(8.h),
                      decoration: IconButtonStyleHelper.fillWhiteA,
                      child: CustomImageView(
                        imagePath: ImageConstant.imgPlus,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 10.v),
                    child: BlocSelector<SurgeonSLoungeBloc, SurgeonSLoungeState,
                        TextEditingController?>(
                      selector: (state) => state.messageController,
                      builder: (context, messageController) {
                        return CustomTextFormField(
                          width: 214.h,
                          controller: messageController,
                          hintText: "lbl_message".tr,
                          textInputAction: TextInputAction.done,
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 10.v),
                    child: CustomIconButton(
                      height: 40.adaptSize,
                      width: 40.adaptSize,
                      padding: EdgeInsets.all(8.h),
                      decoration: IconButtonStyleHelper.fillWhiteA,
                      child: CustomImageView(
                        imagePath: ImageConstant.imgCamera,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 10.v),
                    child: CustomIconButton(
                      height: 40.adaptSize,
                      width: 40.adaptSize,
                      padding: EdgeInsets.all(8.h),
                      decoration: IconButtonStyleHelper.fillWhiteA,
                      child: CustomImageView(
                        imagePath: ImageConstant.imgMic,
                      ),
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottombar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Activity:
        return AppRoutes.timeCapsulePage;
      case BottomBarEnum.Messagecircle:
        return AppRoutes.wsesGuidelinesHerniasPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.timeCapsulePage:
        return TimeCapsulePage.builder(context);
      case AppRoutes.wsesGuidelinesHerniasPage:
        return WsesGuidelinesHerniasPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
