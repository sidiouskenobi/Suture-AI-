import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import '../models/wses_guidelines_hernias_model.dart';
part 'wses_guidelines_hernias_event.dart';
part 'wses_guidelines_hernias_state.dart';

/// A bloc that manages the state of a WsesGuidelinesHernias according to the event that is dispatched to it.
class WsesGuidelinesHerniasBloc
    extends Bloc<WsesGuidelinesHerniasEvent, WsesGuidelinesHerniasState> {
  WsesGuidelinesHerniasBloc(WsesGuidelinesHerniasState initialState)
      : super(initialState) {
    on<WsesGuidelinesHerniasInitialEvent>(_onInitialize);
  }

  _onInitialize(
    WsesGuidelinesHerniasInitialEvent event,
    Emitter<WsesGuidelinesHerniasState> emit,
  ) async {}
}
