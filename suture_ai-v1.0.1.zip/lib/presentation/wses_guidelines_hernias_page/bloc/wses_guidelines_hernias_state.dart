part of 'wses_guidelines_hernias_bloc.dart';

/// Represents the state of WsesGuidelinesHernias in the application.

// ignore_for_file: must_be_immutable
class WsesGuidelinesHerniasState extends Equatable {
  WsesGuidelinesHerniasState({this.wsesGuidelinesHerniasModelObj});

  WsesGuidelinesHerniasModel? wsesGuidelinesHerniasModelObj;

  @override
  List<Object?> get props => [wsesGuidelinesHerniasModelObj];
  WsesGuidelinesHerniasState copyWith(
      {WsesGuidelinesHerniasModel? wsesGuidelinesHerniasModelObj}) {
    return WsesGuidelinesHerniasState(
      wsesGuidelinesHerniasModelObj:
          wsesGuidelinesHerniasModelObj ?? this.wsesGuidelinesHerniasModelObj,
    );
  }
}
