part of 'wses_guidelines_hernias_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///WsesGuidelinesHernias widget.
///
/// Events must be immutable and implement the [Equatable] interface.
class WsesGuidelinesHerniasEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the WsesGuidelinesHernias widget is first created.
class WsesGuidelinesHerniasInitialEvent extends WsesGuidelinesHerniasEvent {
  @override
  List<Object?> get props => [];
}
