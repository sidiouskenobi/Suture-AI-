import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_subtitle_four.dart';
import '../../widgets/app_bar/appbar_subtitle_three.dart';
import '../../widgets/app_bar/appbar_trailing_iconbutton.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import 'bloc/wses_guidelines_hernias_bloc.dart';
import 'models/wses_guidelines_hernias_model.dart'; // ignore_for_file: must_be_immutable

class WsesGuidelinesHerniasPage extends StatelessWidget {
  const WsesGuidelinesHerniasPage({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<WsesGuidelinesHerniasBloc>(
      create: (context) => WsesGuidelinesHerniasBloc(WsesGuidelinesHerniasState(
        wsesGuidelinesHerniasModelObj: WsesGuidelinesHerniasModel(),
      ))
        ..add(WsesGuidelinesHerniasInitialEvent()),
      child: WsesGuidelinesHerniasPage(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<WsesGuidelinesHerniasBloc, WsesGuidelinesHerniasState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            appBar: _buildAppbar(context),
            body: SizedBox(
              width: SizeUtils.width,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildSectionheader(context),
                    Padding(
                      padding: EdgeInsets.only(right: 40.h),
                      child: _buildContentrow(
                        context,
                        rowheadlineOne: "msg_wses_spleen_trauma2".tr,
                        rowdescription: "msg_body_copy_description".tr,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(right: 40.h),
                      child: _buildContentrow(
                        context,
                        rowheadlineOne: "msg_wses_spleen_trauma3".tr,
                        rowdescription: "msg_body_copy_description".tr,
                      ),
                    ),
                    _buildContentrow3(context),
                    Padding(
                      padding: EdgeInsets.only(right: 40.h),
                      child: _buildContentrow(
                        context,
                        rowheadlineOne: "msg_wses_spleen_trauma5".tr,
                        rowdescription: "msg_body_copy_description".tr,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(right: 40.h),
                      child: _buildContentrow(
                        context,
                        rowheadlineOne: "msg_wses_spleen_trauma6".tr,
                        rowdescription: "msg_body_copy_description".tr,
                      ),
                    ),
                    _buildContentrow6(context),
                    _buildContentrow7(context),
                    _buildContentrow8(context)
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppbar(BuildContext context) {
    return CustomAppBar(
      title: Padding(
        padding: EdgeInsets.only(left: 16.h),
        child: Column(
          children: [
            AppbarSubtitleThree(
              text: "msg_wses_spleen_trauma".tr,
              margin: EdgeInsets.only(right: 23.h),
            ),
            SizedBox(height: 2.v),
            AppbarSubtitleFour(
              text: "msg_spleen_trauma_classification".tr,
            )
          ],
        ),
      ),
      actions: [
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgSearchGray900,
          margin: EdgeInsets.only(
            left: 8.h,
            top: 14.v,
            right: 22.h,
          ),
        ),
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgIconBgLightGray900,
          margin: EdgeInsets.only(
            left: 4.h,
            top: 14.v,
            right: 30.h,
          ),
        )
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildSectionheader(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 40.h),
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 18.v,
      ),
      decoration: AppDecoration.fillWhiteA,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(
              top: 4.v,
              bottom: 8.v,
            ),
            child: Text(
              "lbl_2010_2023".tr.toUpperCase(),
              style: CustomTextStyles.titleMedium18,
            ),
          ),
          CustomElevatedButton(
            height: 36.v,
            width: 74.h,
            text: "lbl_view_all".tr,
            buttonStyle: CustomButtonStyles.fillGray,
            buttonTextStyle: theme.textTheme.titleSmall!,
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildContentrow3(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 40.h),
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 12.v,
      ),
      decoration: AppDecoration.fillWhiteA,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImage4,
            height: 72.adaptSize,
            width: 72.adaptSize,
            radius: BorderRadius.circular(
              8.h,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 12.h,
              top: 13.v,
              bottom: 13.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "msg_wses_spleen_trauma4".tr,
                  style: theme.textTheme.titleMedium,
                ),
                SizedBox(height: 4.v),
                Text(
                  "msg_body_copy_description".tr,
                  style: theme.textTheme.bodyLarge,
                )
              ],
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgArrowRight,
            height: 24.adaptSize,
            width: 24.adaptSize,
            margin: EdgeInsets.only(
              left: 11.h,
              top: 24.v,
              bottom: 24.v,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildContentrow6(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 40.h),
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 12.v,
      ),
      decoration: AppDecoration.fillWhiteA,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImage4,
            height: 72.adaptSize,
            width: 72.adaptSize,
            radius: BorderRadius.circular(
              8.h,
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                left: 12.h,
                top: 13.v,
                bottom: 13.v,
              ),
              child: Row(
                children: [
                  Expanded(
                    child: _buildCopy(
                      context,
                      rowheadline: "msg_wses_spleen_trauma7".tr,
                      rowdescription: "msg_body_copy_description".tr,
                    ),
                  ),
                  CustomImageView(
                    imagePath: ImageConstant.imgArrowRight,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                    margin: EdgeInsets.only(
                      left: 9.h,
                      top: 9.v,
                      bottom: 10.v,
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildContentrow7(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 40.h),
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 12.v,
      ),
      decoration: AppDecoration.fillWhiteA,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImage4,
            height: 72.adaptSize,
            width: 72.adaptSize,
            radius: BorderRadius.circular(
              8.h,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 12.h,
              top: 13.v,
              bottom: 13.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "lbl_row_header".tr,
                  style: theme.textTheme.titleMedium,
                ),
                SizedBox(height: 5.v),
                Text(
                  "msg_body_copy_description".tr,
                  style: theme.textTheme.bodyLarge,
                )
              ],
            ),
          ),
          Spacer(),
          CustomImageView(
            imagePath: ImageConstant.imgArrowRight,
            height: 24.adaptSize,
            width: 24.adaptSize,
            margin: EdgeInsets.symmetric(vertical: 24.v),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildContentrow8(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 40.h),
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 12.v,
      ),
      decoration: AppDecoration.fillWhiteA,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImage4,
            height: 72.adaptSize,
            width: 72.adaptSize,
            radius: BorderRadius.circular(
              8.h,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 12.h,
              top: 12.v,
              bottom: 12.v,
            ),
            child: Column(
              children: [
                Text(
                  "lbl_row_header".tr,
                  style: theme.textTheme.titleMedium,
                ),
                Text(
                  "msg_body_copy_description".tr,
                  style: theme.textTheme.bodyLarge,
                )
              ],
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgArrowRight,
            height: 24.adaptSize,
            width: 24.adaptSize,
            margin: EdgeInsets.only(
              left: 8.h,
              top: 24.v,
              bottom: 24.v,
            ),
          )
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildContentrow(
    BuildContext context, {
    required String rowheadlineOne,
    required String rowdescription,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 12.v,
      ),
      decoration: AppDecoration.fillWhiteA,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImage4,
            height: 72.adaptSize,
            width: 72.adaptSize,
            radius: BorderRadius.circular(
              8.h,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 12.h,
              top: 13.v,
              bottom: 13.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  rowheadlineOne,
                  style: theme.textTheme.titleMedium!.copyWith(
                    color: appTheme.black900,
                  ),
                ),
                SizedBox(height: 4.v),
                Text(
                  rowdescription,
                  style: theme.textTheme.bodyLarge!.copyWith(
                    color: appTheme.whiteA700.withOpacity(0.4),
                  ),
                )
              ],
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgArrowRight,
            height: 24.adaptSize,
            width: 24.adaptSize,
            margin: EdgeInsets.only(
              left: 9.h,
              top: 24.v,
              bottom: 24.v,
            ),
          )
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildCopy(
    BuildContext context, {
    required String rowheadline,
    required String rowdescription,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          rowheadline,
          style: theme.textTheme.titleMedium!.copyWith(
            color: appTheme.black900,
          ),
        ),
        SizedBox(height: 4.v),
        Text(
          rowdescription,
          style: theme.textTheme.bodyLarge!.copyWith(
            color: appTheme.whiteA700.withOpacity(0.4),
          ),
        )
      ],
    );
  }
}
