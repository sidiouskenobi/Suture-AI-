import 'package:flutter/material.dart';
import '../core/app_export.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';
import '../presentation/podcast_screen/podcast_screen.dart';
import '../presentation/profile_screen/profile_screen.dart';
import '../presentation/surgeon_s_lounge_screen/surgeon_s_lounge_screen.dart';
import '../presentation/time_capsule_container_screen/time_capsule_container_screen.dart';

class AppRoutes {
  static const String timeCapsuleContainerScreen =
      '/time_capsule_container_screen';

  static const String timeCapsulePage = '/time_capsule_page';

  static const String wsesGuidelinesHerniasPage =
      '/wses_guidelines_hernias_page';

  static const String podcastScreen = '/podcast_screen';

  static const String profileScreen = '/profile_screen';

  static const String surgeonSLoungeScreen = '/surgeon_s_lounge_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        timeCapsuleContainerScreen: TimeCapsuleContainerScreen.builder,
        podcastScreen: PodcastScreen.builder,
        profileScreen: ProfileScreen.builder,
        surgeonSLoungeScreen: SurgeonSLoungeScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: ProfileScreen.builder
      };
}
