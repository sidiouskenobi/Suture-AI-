// ignore_for_file: must_be_immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

// Time Capsule images
  static String imgSearch = '$imagePath/img_search.svg';

  static String imgIconBgLight = '$imagePath/img_icon_bg_light.svg';

  static String imgImage = '$imagePath/img_image.png';

  static String imgHeartOutline = '$imagePath/img_heart_outline.svg';

  static String imgImage72x72 = '$imagePath/img_image_72x72.png';

  static String imgImage1 = '$imagePath/img_image_1.png';

  static String imgImage2 = '$imagePath/img_image_2.png';

  static String imgImage3 = '$imagePath/img_image_3.png';

  static String imgHeartOutlineGray900 =
      '$imagePath/img_heart_outline_gray_900.svg';

// WSES Guidelines Hernias images
  static String imgSearchGray900 = '$imagePath/img_search_gray_900.svg';

  static String imgIconBgLightGray900 =
      '$imagePath/img_icon_bg_light_gray_900.svg';

  static String imgArrowRight = '$imagePath/img_arrow_right.svg';

// Podcast images
  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgMoreHorizontal = '$imagePath/img_more_horizontal.svg';

  static String imgImage1358x358 = '$imagePath/img_image_1_358x358.png';

  static String imgGroup226 = '$imagePath/img_group_226.svg';

  static String imgFrame300 = '$imagePath/img_frame_300.svg';

// Profile images
  static String imgSearchBlack900 = '$imagePath/img_search_black_900.svg';

  static String imgIconBgLightBlack900 =
      '$imagePath/img_icon_bg_light_black_900.svg';

  static String imgImage120x120 = '$imagePath/img_image_120x120.png';

// Surgeon’s Lounge images
  static String imgSearchWhiteA700 = '$imagePath/img_search_white_a700.svg';

  static String imgIconBgLightWhiteA700 =
      '$imagePath/img_icon_bg_light_white_a700.svg';

  static String imgUser = '$imagePath/img_user.svg';

  static String imgCircle = '$imagePath/img_circle.svg';

  static String imgImage197x264 = '$imagePath/img_image_197x264.png';

  static String imgPlus = '$imagePath/img_plus.svg';

  static String imgCamera = '$imagePath/img_camera.svg';

  static String imgMic = '$imagePath/img_mic.svg';

// Common images
  static String imgActivity = '$imagePath/img_activity.svg';

  static String imgMessageCircle = '$imagePath/img_message_circle.svg';

  static String imgImage4 = '$imagePath/img_image_4.png';

  static String imgActivityLightBlue700 =
      '$imagePath/img_activity_light_blue_700.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
